<p align="center">
	<img src="https://i.imgur.com/plp3lJu.jpg" width="600px" hight="100px">
</p>

[![version-2.0](https://img.shields.io/badge/MaskPhish-2.0-green)](https://github.com/jaykali/maskphish/releases/tag/2.0)	[![Twitter](https://img.shields.io/twitter/url/https/twitter.com/cloudposse.svg?style=social&label=Follow%20%40KaliLinux_in)](https://twitter.com/KaliLinux_in)
### Author: https://github.com/jaykali

# MaskPhish
It is a simple Bash Script to hide phishing URL under a normal looking URL(google.com or facebook.com).


## Legal Disclaimer:
FOR EDUCATIONAL PURPOSES ONLY. Usage of MaskPhish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. Use Responsibly!

## Installation 

```
git clone https://github.com/jaykali/maskphish
cd maskphish
bash maskphish.sh
```
(Tested on Kali Linux, Termux & Ubuntu)
## Detailed Article:
https://www.kalilinux.in/2020/07/how-to-hide-phishing-link.html

## Start Disscussion on MaskPhish
Want to discuss about MaskPhish with us? (Click Here)[https://github.com/jaykali/maskphish/discussions/new].

## Screenshot
<p align="center">
	<img src="https://i.imgur.com/1JsWv4I.png" width="600px">
</p>

## Contributors:
You can propose a feature request opening an issue or a pull request.

Here is a list of MaskPhish contributors:

<a href="https://github.com/jaykali/maskphish/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=jaykali/maskphish" />
</a>
